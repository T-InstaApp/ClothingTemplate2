package com.instaapp.clothingtemplate1.ui.activity

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.ImageView
import com.instaapp.clothingtemplate1.MainActivity
import com.instaapp.clothingtemplate1.R

class SplashScreen : AppCompatActivity() {

    private lateinit var zoom: Animation
    private lateinit var img: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash_screen)

        zoom = AnimationUtils.loadAnimation(applicationContext, R.anim.zoom)
        img = findViewById(R.id.image)
        img.startAnimation(zoom)

        val handler = Handler()
        handler.postDelayed({
            val intent = Intent(applicationContext, MainActivity::class.java)
            startActivity(intent)
            finish()
        }, 4000)
    }
}